
import { useState, useEffect } from "react";
import { Calendar, CheckSquare, BookOpen, Menu, X, Clock, LogOut, CalendarDays } from "lucide-react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useTasks } from "@/hooks/useTasks";
import { Button } from "@/components/ui/button";
import TodoList from "@/components/TodoList";
import SchoolGuide from "@/components/SchoolGuide";
import Dashboard from "@/components/Dashboard";
import TimetableSection from "@/components/TimetableSection";
import TermDates from "@/components/TermDates";
import WelcomePage from "@/components/WelcomePage";

const Index = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const { tasks, loading: tasksLoading, addTask, updateTask, deleteTask, toggleTask } = useTasks();
  const [userName, setUserName] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState("dashboard");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Check for stored username or user profile data on component mount
  useEffect(() => {
    if (user) {
      // First check localStorage for stored username
      const storedName = localStorage.getItem('userName');
      if (storedName) {
        setUserName(storedName);
      } else if (user.user_metadata?.full_name) {
        // If no stored name but user has full_name in metadata, use that
        setUserName(user.user_metadata.full_name);
        localStorage.setItem('userName', user.user_metadata.full_name);
      }
    }
  }, [user]);

  // Show loading while checking auth
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Redirect to auth if not logged in
  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  const handleNameSubmit = (name: string) => {
    setUserName(name);
    localStorage.setItem('userName', name);
  };

  // Show welcome page only if user hasn't entered their name and it's not in their profile
  if (!userName) {
    return <WelcomePage onNameSubmit={handleNameSubmit} />;
  }

  const handleSignOut = async () => {
    try {
      // Clear stored username on sign out
      localStorage.removeItem('userName');
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  // Menu items for navigation
  const menuItems = [
    { id: "dashboard", name: "Dashboard", icon: Calendar },
    { id: "todos", name: "To-Do List", icon: CheckSquare },
    { id: "timetable", name: "Timetable", icon: Clock },
    { id: "term-dates", name: "Term Dates", icon: CalendarDays },
    { id: "guide", name: "Jumeirah College Guide", icon: BookOpen },
  ];

  // Render the active section based on the current state
  const renderActiveSection = () => {
    if (tasksLoading) {
      return (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      );
    }

    switch (activeSection) {
      case "todos":
        return (
          <TodoList 
            tasks={tasks}
            onAddTask={addTask}
            onUpdateTask={updateTask}
            onDeleteTask={deleteTask}
            onToggleTask={toggleTask}
          />
        );
      case "timetable":
        return <TimetableSection />;
      case "term-dates":
        return <TermDates />;
      case "guide":
        return <SchoolGuide />;
      default:
        return (
          <Dashboard 
            onNavigate={setActiveSection}
            tasks={tasks}
            onAddTask={addTask}
            onUpdateTask={updateTask}
            onDeleteTask={deleteTask}
            onToggleTask={toggleTask}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <img 
                src="/lovable-uploads/e2b80da7-76e3-475a-8504-890c34a48ccc.png" 
                alt="Jumeirah College Logo"
                className="h-10 w-auto"
              />
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
                  JC Planner
                </h1>
                <p className="text-xs text-gray-500">Welcome, {userName}!</p>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                      activeSection === item.id
                        ? "bg-blue-100 text-blue-700 shadow-sm"
                        : "text-gray-600 hover:text-blue-600 hover:bg-gray-50"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="font-medium">{item.name}</span>
                  </button>
                );
              })}
            </nav>

            {/* User Menu */}
            <div className="hidden md:flex items-center">
              <Button
                onClick={handleSignOut}
                variant="outline"
                size="sm"
                className="flex items-center space-x-1 text-xs"
              >
                <LogOut className="h-3 w-3" />
                <span>Sign Out</span>
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg text-gray-600 hover:text-blue-600 hover:bg-gray-50"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-2 space-y-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveSection(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 ${
                      activeSection === item.id
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-blue-600 hover:bg-gray-50"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.name}</span>
                  </button>
                );
              })}
              <div className="border-t border-gray-200 pt-2">
                <Button
                  onClick={handleSignOut}
                  variant="outline"
                  size="sm"
                  className="w-full flex items-center space-x-1 text-xs"
                >
                  <LogOut className="h-3 w-3" />
                  <span>Sign Out</span>
                </Button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderActiveSection()}
      </main>
    </div>
  );
};

export default Index;
