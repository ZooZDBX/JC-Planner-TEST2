
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, FileText, Edit3, Save, X, Download, Calendar } from 'lucide-react';
import { useTimetableProcessor } from '@/hooks/useTimetableProcessor';
import TimetableHeader from './timetable/TimetableHeader';
import TimetableRow from './timetable/TimetableRow';
import FormattedTimetable from './FormattedTimetable';
import { useToast } from '@/hooks/use-toast';

const TimetableSection = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('upload');
  const { toast } = useToast();
  
  const {
    timetableData,
    isProcessing,
    error,
    editingData,
    processImage,
    updateTimetableData,
    setEditingData,
    clearTimetable,
    saveTimetable
  } = useTimetableProcessor();

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        await processImage(file);
        setActiveTab('manual');
        toast({
          title: "Image processed successfully",
          description: "You can now review and edit your timetable.",
        });
      } catch (error) {
        console.error('Upload failed:', error);
        toast({
          title: "Upload failed",
          description: "Please try again with a clear image of your timetable.",
          variant: "destructive",
        });
      }
    }
  };

  const handleSave = () => {
    saveTimetable();
    setIsEditing(false);
    toast({
      title: "Timetable saved",
      description: "Your changes have been saved successfully.",
    });
  };

  const handleCancel = () => {
    setEditingData(timetableData);
    setIsEditing(false);
  };

  const handleCellChange = (day: string, period: string, field: 'subject' | 'classroom' | 'teacher', value: string) => {
    setEditingData(prev => ({
      ...prev,
      [day]: {
        ...prev[day],
        [period]: {
          ...prev[day]?.[period],
          [field]: value
        }
      }
    }));
  };

  const exportTimetable = () => {
    const dataStr = JSON.stringify(timetableData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'timetable.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const periods = [
    { id: 'registration', label: 'Registration', time: '07:45 - 07:50' },
    { id: 'period1', label: 'Period 1', time: '07:50 - 08:45' },
    { id: 'period2', label: 'Period 2', time: '08:45 - 09:40' },
    { id: 'break', label: 'Break', time: '09:40 - 10:00' },
    { id: 'period3', label: 'Period 3', time: '10:00 - 10:55' },
    { id: 'period4', label: 'Period 4', time: '10:55 - 11:50' },
    { id: 'lunch', label: 'Lunch', time: '11:50 - 12:30' },
    { id: 'period5', label: 'Period 5', time: '12:30 - 13:10' },
    { id: 'period6', label: 'Period 6', time: '13:10 - 14:05' },
    { id: 'period7', label: 'Period 7', time: '14:05 - 15:00' }
  ];

  const fridayPeriods = [
    { id: 'registration', label: 'Registration', time: '07:45 - 07:50' },
    { id: 'period1', label: 'Period 1', time: '07:50 - 08:35' },
    { id: 'period2', label: 'Period 2', time: '08:35 - 09:20' },
    { id: 'break', label: 'Break', time: '09:20 - 09:40' },
    { id: 'period3', label: 'Period 3', time: '09:40 - 10:25' },
    { id: 'period4', label: 'Period 4', time: '10:25 - 11:10' },
    { id: 'lunch', label: 'Lunch', time: '11:10 - 11:50' },
    { id: 'period5', label: 'Period 5', time: '11:50 - 12:35' },
    { id: 'period6', label: 'Period 6', time: '12:35 - 13:20' }
  ];

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">Weekly Timetable</h3>
          <p className="text-gray-600">Upload your timetable image or create it manually</p>
        </div>
        {Object.keys(timetableData).length > 0 && (
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={exportTimetable}
              className="flex items-center space-x-2"
            >
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={clearTimetable}
              className="flex items-center space-x-2 text-red-600 hover:text-red-700"
            >
              <X className="h-4 w-4" />
              <span>Clear</span>
            </Button>
          </div>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upload" className="flex items-center space-x-2">
            <Upload className="h-4 w-4" />
            <span>Upload Image</span>
          </TabsTrigger>
          <TabsTrigger value="manual" className="flex items-center space-x-2">
            <Edit3 className="h-4 w-4" />
            <span>Manual Entry</span>
          </TabsTrigger>
          <TabsTrigger value="formatted" className="flex items-center space-x-2">
            <Calendar className="h-4 w-4" />
            <span>View Timetable</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Upload Timetable Image</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-gray-900 mb-2">
                  Upload your timetable image
                </h4>
                <p className="text-gray-600 mb-4">
                  Take a clear photo or screenshot of your timetable. The AI will extract the schedule information automatically.
                </p>
                <label htmlFor="timetable-upload" className="cursor-pointer">
                  <Button className="inline-flex" disabled={isProcessing}>
                    {isProcessing ? 'Processing...' : 'Choose Image'}
                  </Button>
                  <input
                    id="timetable-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    disabled={isProcessing}
                  />
                </label>
              </div>
              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-700">{error}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="manual" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Edit3 className="h-5 w-5" />
                  <span>Manual Timetable Entry</span>
                </div>
                <div className="flex space-x-2">
                  {isEditing ? (
                    <>
                      <Button size="sm" onClick={handleSave} className="flex items-center space-x-1">
                        <Save className="h-4 w-4" />
                        <span>Save</span>
                      </Button>
                      <Button size="sm" variant="outline" onClick={handleCancel} className="flex items-center space-x-1">
                        <X className="h-4 w-4" />
                        <span>Cancel</span>
                      </Button>
                    </>
                  ) : (
                    <Button size="sm" onClick={() => setIsEditing(true)} className="flex items-center space-x-1">
                      <Edit3 className="h-4 w-4" />
                      <span>Edit</span>
                    </Button>
                  )}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <div className="min-w-full border border-gray-200 rounded-lg">
                  <TimetableHeader />
                  {days.map((day) => (
                    <TimetableRow
                      key={day}
                      day={day}
                      periods={day === 'Friday' ? fridayPeriods : periods}
                      data={isEditing ? editingData : timetableData}
                      isEditing={isEditing}
                      onCellChange={handleCellChange}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="formatted" className="space-y-4">
          {Object.keys(timetableData).length > 0 ? (
            <FormattedTimetable timetableData={timetableData} />
          ) : (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-medium text-gray-900 mb-2">No timetable data</h4>
                  <p className="text-gray-600">Upload an image or create your timetable manually to see it here.</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TimetableSection;
