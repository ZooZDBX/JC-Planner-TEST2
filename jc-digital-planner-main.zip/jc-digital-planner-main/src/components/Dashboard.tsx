
import { CheckSquare, BookOpen, Calendar, TrendingUp, Clock, MapPin } from "lucide-react";
import TaskCalendar from "./TaskCalendar";
import Notes from "./Notes";
import { useEffect, useState } from "react";

interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  priority: "high" | "medium" | "low";
  dueDate: string;
  time?: string;
}

interface TimetableEntry {
  time: string;
  monday: { subject: string; classroom: string };
  tuesday: { subject: string; classroom: string };
  wednesday: { subject: string; classroom: string };
  thursday: { subject: string; classroom: string };
  friday: { subject: string; classroom: string };
}

interface DashboardProps {
  onNavigate: (section: string) => void;
  tasks: Task[];
  onAddTask: (task: Omit<Task, 'id'>) => void;
  onUpdateTask: (id: string, updates: Partial<Task>) => void;
  onDeleteTask: (id: string) => void;
  onToggleTask: (id: string) => void;
}

const Dashboard = ({ onNavigate, tasks, onAddTask, onUpdateTask, onDeleteTask, onToggleTask }: DashboardProps) => {
  const [todaysLessons, setTodaysLessons] = useState<{ time: string; subject: string; classroom: string }[]>([]);
  
  useEffect(() => {
    // Load timetable data and get today's lessons
    const savedTimetable = localStorage.getItem('formattedTimetable');
    if (savedTimetable) {
      try {
        const timetableData: TimetableEntry[] = JSON.parse(savedTimetable);
        const today = new Date();
        const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        const todayName = dayNames[today.getDay()];
        
        if (todayName !== 'sunday' && todayName !== 'saturday') {
          const lessons = timetableData
            .map(entry => {
              const dayData = entry[todayName as keyof TimetableEntry];
              // Handle both old format (string) and new format (object)
              if (typeof dayData === 'string') {
                return {
                  time: entry.time,
                  subject: dayData,
                  classroom: ''
                };
              } else if (dayData && typeof dayData === 'object') {
                return {
                  time: entry.time,
                  subject: dayData.subject || '',
                  classroom: dayData.classroom || ''
                };
              }
              return null;
            })
            .filter(item => item && item.subject && item.subject.trim() !== '' && item.subject !== '-')
            .map(item => item!);
          
          setTodaysLessons(lessons);
        }
      } catch (error) {
        console.error('Failed to parse timetable data:', error);
      }
    }
  }, []);

  const completedToday = tasks.filter(task => 
    task.completed && task.dueDate === new Date().toISOString().split('T')[0]
  ).length;
  
  const pendingTasks = tasks.filter(task => !task.completed).length;
  
  // Fix the "This Week" calculation to properly count completed tasks
  const completedThisWeek = tasks.filter(task => {
    if (!task.completed) return false;
    
    const taskDate = new Date(task.dueDate);
    const today = new Date();
    
    // Get the start of the current week (Sunday)
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    
    // Get the end of the current week (Saturday)
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);
    
    return taskDate >= startOfWeek && taskDate <= endOfWeek;
  }).length;

  const quickStats = [
    { label: "Pending Tasks", value: pendingTasks.toString(), color: "text-orange-600", bg: "bg-orange-50" },
    { label: "Completed Today", value: completedToday.toString(), color: "text-green-600", bg: "bg-green-50" },
    { label: "This Week", value: completedThisWeek.toString(), color: "text-blue-600", bg: "bg-blue-50" },
  ];

  const quickActions = [
    {
      title: "Manage Tasks",
      description: "Add, edit, and track your homework and assignments",
      icon: CheckSquare,
      action: () => onNavigate("todos"),
      gradient: "from-blue-500 to-blue-600",
    },
    {
      title: "School Guide",
      description: "Access school rules, policies, and important information",
      icon: BookOpen,
      action: () => onNavigate("guide"),
      gradient: "from-emerald-500 to-emerald-600",
    },
  ];

  // Format today's date
  const today = new Date();
  const todayFormatted = today.toLocaleDateString('en-GB', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="space-y-8">
      {/* Date and Welcome Section */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-2 text-gray-600 mb-2">
          <Calendar className="h-5 w-5" />
          <span className="text-lg font-medium">{todayFormatted}</span>
        </div>
        <h2 className="text-3xl font-bold text-gray-900">Welcome to Your School Planner</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Stay organized, track your progress, and never miss an assignment. Your academic success starts here!
        </p>
      </div>

      {/* Today's Lessons */}
      {todaysLessons.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-900">Today's Timetable</h3>
            </div>
            <button
              onClick={() => onNavigate("timetable")}
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              View Full Timetable
            </button>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-2">
            {todaysLessons.map((lesson, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-4 hover:shadow-md transition-shadow flex-shrink-0 min-w-[200px]">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-blue-800 bg-blue-100 px-2 py-1 rounded">
                      {lesson.time}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 text-base">{lesson.subject}</h4>
                    {lesson.classroom && (
                      <div className="flex items-center space-x-1 mt-1">
                        <MapPin className="h-3 w-3 text-gray-500" />
                        <span className="text-sm text-gray-600">{lesson.classroom}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {quickStats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
              <div className={`p-3 rounded-lg ${stat.bg}`}>
                <TrendingUp className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions and Notes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <div className="space-y-6">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <div
                key={index}
                onClick={action.action}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 cursor-pointer transform transition-all duration-200 hover:scale-105 hover:shadow-lg"
              >
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${action.gradient}`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{action.title}</h3>
                    <p className="text-gray-600">{action.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Notes Section */}
        <Notes />
      </div>

      {/* Task Calendar Section */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center space-y-4 mb-6">
          <Calendar className="h-12 w-12 mx-auto text-blue-600" />
          <h3 className="text-2xl font-bold text-gray-900">Task Calendar</h3>
          <p className="text-gray-600">
            View and manage your tasks in calendar format. Schedule assignments and track your progress.
          </p>
        </div>
        <TaskCalendar
          tasks={tasks}
          onAddTask={onAddTask}
          onUpdateTask={onUpdateTask}
          onDeleteTask={onDeleteTask}
          onToggleTask={onToggleTask}
        />
      </div>
    </div>
  );
};

export default Dashboard;
