
import { useState, useEffect } from "react";
import { List, Save, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import confetti from 'canvas-confetti';

interface NoteItem {
  id: string;
  text: string;
  completed: boolean;
}

const Notes = () => {
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [newNote, setNewNote] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  // Load notes from localStorage on component mount
  useEffect(() => {
    const savedNotes = localStorage.getItem('dailyNotes');
    if (savedNotes) {
      try {
        const parsedNotes = JSON.parse(savedNotes);
        setNotes(Array.isArray(parsedNotes) ? parsedNotes : []);
      } catch (error) {
        setNotes([]);
      }
    }
  }, []);

  // Auto-save notes whenever notes state changes
  useEffect(() => {
    if (notes.length >= 0) { // Save even when notes array is empty
      try {
        localStorage.setItem('dailyNotes', JSON.stringify(notes));
      } catch (error) {
        console.error('Failed to save notes:', error);
      }
    }
  }, [notes]);

  const addNote = () => {
    if (newNote.trim()) {
      const noteItem: NoteItem = {
        id: Date.now().toString(),
        text: newNote.trim(),
        completed: false
      };
      setNotes([...notes, noteItem]);
      setNewNote("");
    }
  };

  const toggleNote = (id: string) => {
    const note = notes.find(n => n.id === id);
    if (note && !note.completed) {
      // Trigger confetti when completing a note
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
    
    setNotes(notes.map(note => 
      note.id === id ? { ...note, completed: !note.completed } : note
    ));
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      addNote();
    }
  };

  const handleManualSave = () => {
    setIsSaving(true);
    try {
      localStorage.setItem('dailyNotes', JSON.stringify(notes));
      toast({
        title: "Notes saved!",
        description: "Your notes have been saved successfully.",
      });
    } catch (error) {
      toast({
        title: "Error saving notes",
        description: "There was an issue saving your notes. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <List className="h-5 w-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">Daily Notes</h3>
        </div>
        <Button
          onClick={handleManualSave}
          disabled={isSaving}
          size="sm"
          className="flex items-center space-x-1"
        >
          <Save className="h-3 w-3" />
          <span>{isSaving ? "Saving..." : "Save"}</span>
        </Button>
      </div>
      
      <div className="space-y-4">
        {/* Add new note input */}
        <div className="flex items-center space-x-2">
          <Input
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Add a new note..."
            className="flex-1"
          />
          <Button
            onClick={addNote}
            size="sm"
            disabled={!newNote.trim()}
            className="flex items-center space-x-1"
          >
            <Plus className="h-3 w-3" />
            <span>Add</span>
          </Button>
        </div>

        {/* Notes list */}
        <div className="space-y-2 max-h-[200px] overflow-y-auto">
          {notes.length === 0 ? (
            <p className="text-gray-500 text-sm italic">No notes yet. Add your first note above!</p>
          ) : (
            notes.map((note) => (
              <div key={note.id} className="flex items-center space-x-2 group">
                <Checkbox
                  checked={note.completed}
                  onCheckedChange={() => toggleNote(note.id)}
                />
                <span
                  className={`flex-1 text-sm ${
                    note.completed 
                      ? 'line-through text-gray-500' 
                      : 'text-gray-900'
                  }`}
                >
                  {note.text}
                </span>
                <button
                  onClick={() => deleteNote(note.id)}
                  className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 text-xs transition-opacity"
                >
                  Delete
                </button>
              </div>
            ))
          )}
        </div>

        <p className="text-xs text-gray-500">
          Notes are automatically saved as you make changes.
        </p>
      </div>
    </div>
  );
};

export default Notes;
