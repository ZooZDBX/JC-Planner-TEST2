
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { User } from 'lucide-react';

interface WelcomePageProps {
  onNameSubmit: (name: string) => void;
}

const WelcomePage = ({ onNameSubmit }: WelcomePageProps) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onNameSubmit(name.trim());
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50 flex items-center justify-center">
      <div className="max-w-md w-full mx-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <img 
              src="/lovable-uploads/e2b80da7-76e3-475a-8504-890c34a48ccc.png" 
              alt="Jumeirah College Logo"
              className="h-20 w-auto"
            />
          </div>

          {/* Title */}
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent mb-2">
            Welcome to JC Planner
          </h1>
          <p className="text-gray-600 mb-8">
            Let's get started by setting up your personal planner
          </p>

          {/* Name Input Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <User className="h-5 w-5 text-blue-600" />
                <label htmlFor="name" className="text-sm font-medium text-gray-700">
                  What's your name?
                </label>
              </div>
              <Input
                id="name"
                type="text"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="text-center text-lg"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white transition-all duration-200"
              size="lg"
              disabled={!name.trim()}
            >
              Enter JC Planner
            </Button>
          </form>

          {/* Info text */}
          <div className="mt-6 text-xs text-gray-500">
            Your name will be used to personalize your planner experience
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomePage;
