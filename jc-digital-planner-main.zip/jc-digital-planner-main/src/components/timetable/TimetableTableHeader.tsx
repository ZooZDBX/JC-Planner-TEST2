
import { TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface TimetableTableHeaderProps {
  isLegacyFormat?: boolean;
}

const TimetableTableHeader = ({ isLegacyFormat = false }: TimetableTableHeaderProps) => {
  return (
    <TableHeader>
      <TableRow>
        <TableHead className="w-24">Time</TableHead>
        <TableHead>Monday</TableHead>
        <TableHead>Tuesday</TableHead>
        <TableHead>Wednesday</TableHead>
        <TableHead>Thursday</TableHead>
        <TableHead className="bg-blue-50 font-semibold">Friday Times</TableHead>
        <TableHead>Friday</TableHead>
      </TableRow>
    </TableHeader>
  );
};

export default TimetableTableHeader;
