
interface TimetableCellDisplayProps {
  subject: string;
  classroom: string;
  teacher: string;
}

const TimetableCellDisplay = ({ subject, classroom, teacher }: TimetableCellDisplayProps) => {
  const hasContent = (subject && subject !== '-') || (classroom && classroom !== '-') || (teacher && teacher !== '-');
  
  if (!hasContent) {
    return <div className="text-sm">-</div>;
  }

  return (
    <div className="text-sm">
      {subject && subject !== '-' && (
        <div className="font-medium">{subject}</div>
      )}
      {classroom && classroom !== '-' && (
        <div className="text-muted-foreground text-xs">{classroom}</div>
      )}
      {teacher && teacher !== '-' && (
        <div className="text-muted-foreground text-xs italic">{teacher}</div>
      )}
    </div>
  );
};

export default TimetableCellDisplay;
