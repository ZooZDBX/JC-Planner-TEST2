
import { TableCell, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import TimetableCellEditor from "./TimetableCellEditor";
import TimetableCellDisplay from "./TimetableCellDisplay";

interface TimetableEntry {
  time: string;
  monday: { subject: string; classroom: string; teacher: string };
  tuesday: { subject: string; classroom: string; teacher: string };
  wednesday: { subject: string; classroom: string; teacher: string };
  thursday: { subject: string; classroom: string; teacher: string };
  friday: { subject: string; classroom: string; teacher: string };
}

interface TimetableRowProps {
  entry: TimetableEntry;
  index: number;
  isEditing: boolean;
  fridayTimes: string[];
  onTimeUpdate: (index: number, value: string) => void;
  onCellUpdate: (index: number, day: keyof Omit<TimetableEntry, 'time'>, field: 'subject' | 'classroom' | 'teacher', value: string) => void;
  section: 'weekdays' | 'friday' | 'main';
  fridayEntry?: TimetableEntry;
}

const TimetableRowComponent = ({ 
  entry, 
  index, 
  isEditing, 
  fridayTimes, 
  onTimeUpdate, 
  onCellUpdate, 
  section,
  fridayEntry 
}: TimetableRowProps) => {
  const weekdays = ['monday', 'tuesday', 'wednesday', 'thursday'] as const;

  return (
    <TableRow>
      <TableCell className="font-medium">
        {isEditing ? (
          <Input
            value={entry.time}
            onChange={(e) => onTimeUpdate(index, e.target.value)}
            className="w-20 text-xs"
          />
        ) : (
          entry.time
        )}
      </TableCell>
      
      {weekdays.map((day) => {
        const dayData = entry[day];
        return (
          <TableCell key={day} className="min-w-[150px]">
            {isEditing ? (
              <TimetableCellEditor
                subject={dayData.subject}
                classroom={dayData.classroom}
                teacher={dayData.teacher}
                onSubjectChange={(value) => onCellUpdate(index, day, 'subject', value)}
                onClassroomChange={(value) => onCellUpdate(index, day, 'classroom', value)}
                onTeacherChange={(value) => onCellUpdate(index, day, 'teacher', value)}
              />
            ) : (
              <TimetableCellDisplay
                subject={dayData.subject}
                classroom={dayData.classroom}
                teacher={dayData.teacher}
              />
            )}
          </TableCell>
        );
      })}
      
      {/* Friday Times Column */}
      <TableCell className="bg-blue-50 font-medium text-center">
        {fridayTimes[index] || '-'}
      </TableCell>
      
      {/* Friday Subject Column */}
      <TableCell className="min-w-[150px]">
        {fridayEntry ? (
          isEditing ? (
            <TimetableCellEditor
              subject={fridayEntry.friday.subject}
              classroom={fridayEntry.friday.classroom}
              teacher={fridayEntry.friday.teacher}
              onSubjectChange={(value) => onCellUpdate(index, 'friday', 'subject', value)}
              onClassroomChange={(value) => onCellUpdate(index, 'friday', 'classroom', value)}
              onTeacherChange={(value) => onCellUpdate(index, 'friday', 'teacher', value)}
            />
          ) : (
            <TimetableCellDisplay
              subject={fridayEntry.friday.subject}
              classroom={fridayEntry.friday.classroom}
              teacher={fridayEntry.friday.teacher}
            />
          )
        ) : (
          isEditing ? (
            <TimetableCellEditor
              subject={entry.friday.subject}
              classroom={entry.friday.classroom}
              teacher={entry.friday.teacher}
              onSubjectChange={(value) => onCellUpdate(index, 'friday', 'subject', value)}
              onClassroomChange={(value) => onCellUpdate(index, 'friday', 'classroom', value)}
              onTeacherChange={(value) => onCellUpdate(index, 'friday', 'teacher', value)}
            />
          ) : (
            <TimetableCellDisplay
              subject={entry.friday.subject}
              classroom={entry.friday.classroom}
              teacher={entry.friday.teacher}
            />
          )
        )}
      </TableCell>
    </TableRow>
  );
};

export default TimetableRowComponent;
