
import { Button } from "@/components/ui/button";
import { Edit2, Save, X } from "lucide-react";

interface TimetableHeaderProps {
  isEditing: boolean;
  onEdit: () => void;
  onSave: () => void;
  onCancel: () => void;
}

const TimetableHeader = ({ isEditing, onEdit, onSave, onCancel }: TimetableHeaderProps) => {
  return (
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-2xl font-bold">Your Timetable</h2>
      <div className="flex space-x-2">
        {!isEditing ? (
          <Button onClick={onEdit} variant="outline" size="sm">
            <Edit2 className="h-4 w-4 mr-1" />
            Edit
          </Button>
        ) : (
          <>
            <Button onClick={onSave} variant="outline" size="sm">
              <Save className="h-4 w-4 mr-1" />
              Save
            </Button>
            <Button onClick={onCancel} variant="outline" size="sm">
              <X className="h-4 w-4 mr-1" />
              Cancel
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

export default TimetableHeader;
