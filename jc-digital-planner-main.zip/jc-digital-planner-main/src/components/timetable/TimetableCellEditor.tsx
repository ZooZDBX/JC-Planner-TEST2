
import { Input } from "@/components/ui/input";

interface TimetableCellEditorProps {
  subject: string;
  classroom: string;
  teacher: string;
  onSubjectChange: (value: string) => void;
  onClassroomChange: (value: string) => void;
  onTeacherChange: (value: string) => void;
}

const TimetableCellEditor = ({ 
  subject, 
  classroom, 
  teacher,
  onSubjectChange, 
  onClassroomChange,
  onTeacherChange
}: TimetableCellEditorProps) => {
  return (
    <div className="space-y-1">
      <Input
        value={subject}
        onChange={(e) => onSubjectChange(e.target.value)}
        placeholder="Subject"
        className="text-xs"
      />
      <Input
        value={classroom}
        onChange={(e) => onClassroomChange(e.target.value)}
        placeholder="Classroom"
        className="text-xs"
      />
      <Input
        value={teacher}
        onChange={(e) => onTeacherChange(e.target.value)}
        placeholder="Teacher"
        className="text-xs"
      />
    </div>
  );
};

export default TimetableCellEditor;
