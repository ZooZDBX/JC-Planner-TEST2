
import { Calendar, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const TermDates = () => {
  const termData = {
    winter2025: {
      title: "Winter Term 2025",
      events: [
        { event: "New staff Induction", date: "Monday 18 August — Wednesday 20 August" },
        { event: "Middle Leaders", date: "Wednesday 20 August" },
        { event: "All Staff Training Days", date: "Thursday 21 August — Friday 22 August" },
        { event: "Start of term for Students", date: "Monday 25 August" },
        { event: "Prophet's Birthday", date: "Thursday 4 September", isHoliday: true },
        { event: "PD Day", date: "Friday 10 October" },
        { event: "Half Term", date: "Monday 13 October — Friday 17 October (inclusive)", isBreak: true },
        { event: "National Commemoration Day & UAE National Day Holiday", date: "Tuesday 2 December — Wednesday 3 December", isHoliday: true },
        { event: "Last day of term", date: "Friday 12 December" }
      ]
    },
    spring2026: {
      title: "Spring Term 2026",
      events: [
        { event: "Start of term", date: "Monday 5 January" },
        { event: "PD Day", date: "Friday 6 February" },
        { event: "Half Term", date: "Monday 9 February — Wednesday 11 February (inclusive)", isBreak: true },
        { event: "Start of Ramadan", date: "Tuesday 17 February", isHoliday: true },
        { event: "Last day of term", date: "Wednesday 18 March" },
        { event: "Eid Al Fitr", date: "Thursday 19 March — Friday 20 March", isHoliday: true }
      ]
    },
    summer2026: {
      title: "Summer Term 2026",
      events: [
        { event: "Start of term", date: "Monday 6 April" },
        { event: "PD Day", date: "Monday 25 May" },
        { event: "Eid Al Adha", date: "Tuesday 26 May — Friday 29 May", isHoliday: true },
        { event: "Islamic New Year", date: "Tuesday 16 June", isHoliday: true },
        { event: "Last day of term", date: "Friday 3 July" }
      ]
    }
  };

  const getEventBadge = (event: any) => {
    if (event.isHoliday) {
      return <Badge variant="secondary" className="ml-2 text-xs bg-green-100 text-green-800">Holiday</Badge>;
    }
    if (event.isBreak) {
      return <Badge variant="outline" className="ml-2 text-xs">Break</Badge>;
    }
    return null;
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Academic Calendar 2025-26</h3>
        <p className="text-gray-600">
          Important dates for the academic year including term dates, holidays, and professional development days.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-3">
        {Object.values(termData).map((term, index) => (
          <Card key={index} className="h-fit">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Calendar className="h-5 w-5 text-blue-600" />
                <span>{term.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {term.events.map((event, eventIndex) => (
                  <div key={eventIndex} className="border-l-2 border-blue-100 pl-4 py-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 text-sm flex items-center">
                          {event.event}
                          {getEventBadge(event)}
                        </h4>
                        <div className="flex items-center space-x-1 mt-1">
                          <Clock className="h-3 w-3 text-gray-400" />
                          <p className="text-xs text-gray-600">{event.date}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start space-x-2">
          <div className="flex-shrink-0">
            <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
          </div>
          <div>
            <p className="text-sm text-yellow-800 font-medium">Important Note</p>
            <p className="text-sm text-yellow-700 mt-1">
              *All Islamic holidays are subject to confirmation from the Ministry of Education
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermDates;
