
import React from 'react';
import { Button } from '@/components/ui/button';
import { BookOpen, Calendar, CheckSquare, AlertCircle } from 'lucide-react';

const LoginPage = () => {
  const handleGetStarted = () => {
    // For now, just show an alert since authentication is removed
    alert('Authentication has been removed. You can now access the app directly!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50 flex items-center justify-center">
      <div className="max-w-md w-full mx-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-r from-blue-600 to-emerald-600 p-4 rounded-xl">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent mb-2">
            School Planner
          </h1>
          <p className="text-gray-600 mb-8">
            Stay organized with your homework, track progress, and access school resources all in one place.
          </p>

          {/* Features */}
          <div className="space-y-4 mb-8">
            <div className="flex items-center space-x-3 text-left">
              <CheckSquare className="h-5 w-5 text-blue-600 flex-shrink-0" />
              <span className="text-gray-700">Manage homework and assignments</span>
            </div>
            <div className="flex items-center space-x-3 text-left">
              <Calendar className="h-5 w-5 text-emerald-600 flex-shrink-0" />
              <span className="text-gray-700">Organize your schedule</span>
            </div>
            <div className="flex items-center space-x-3 text-left">
              <BookOpen className="h-5 w-5 text-blue-600 flex-shrink-0" />
              <span className="text-gray-700">Access school rules and guidelines</span>
            </div>
          </div>

          {/* Get Started Button */}
          <Button
            onClick={handleGetStarted}
            className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white transition-all duration-200 mb-4"
            size="lg"
          >
            Get Started
          </Button>

          {/* Info text */}
          <div className="bg-blue-50 p-3 rounded-lg">
            <div className="flex items-start space-x-2">
              <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-xs text-blue-700 text-left">
                <p className="font-medium mb-1">Authentication Removed</p>
                <p>This app now runs without authentication. All features are accessible directly.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
