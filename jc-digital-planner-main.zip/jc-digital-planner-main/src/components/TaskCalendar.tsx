import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Check, Edit3, Save, X, Trash2 } from "lucide-react";
import { format } from "date-fns";
import confetti from 'canvas-confetti';

interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  priority: "high" | "medium" | "low";
  dueDate: string;
  time?: string;
  completedAt?: string;
}

interface TaskCalendarProps {
  tasks: Task[];
  onAddTask: (task: Omit<Task, 'id'>) => void;
  onUpdateTask: (id: string, updates: Partial<Task>) => void;
  onDeleteTask: (id: string) => void;
  onToggleTask: (id: string) => void;
}

const TaskCalendar = ({ tasks, onAddTask, onUpdateTask, onDeleteTask, onToggleTask }: TaskCalendarProps) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "medium" as const,
    time: "",
  });

  const selectedDateStr = selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '';
  const tasksForSelectedDate = tasks.filter(task => task.dueDate === selectedDateStr);

  const handleToggleTask = (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (task && !task.completed) {
      // Trigger confetti when completing a task
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      // Add completion timestamp
      onUpdateTask(id, { completed: true, completedAt: new Date().toISOString() });
    } else if (task && task.completed) {
      // Remove completion timestamp when unchecking
      onUpdateTask(id, { completed: false, completedAt: undefined });
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-700 bg-gradient-to-r from-red-50 to-pink-50 border-red-300";
      case "medium": return "text-amber-700 bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-300";
      case "low": return "text-emerald-700 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-300";
      default: return "text-gray-700 bg-gradient-to-r from-gray-50 to-slate-50 border-gray-300";
    }
  };

  const addTaskToDate = () => {
    if (newTask.title.trim() && selectedDate) {
      const task: Omit<Task, 'id'> = {
        title: newTask.title,
        description: newTask.description,
        completed: false,
        priority: newTask.priority,
        dueDate: selectedDateStr,
        time: newTask.time,
      };
      onAddTask(task);
      setNewTask({ title: "", description: "", priority: "medium", time: "" });
      setShowAddForm(false);
    }
  };

  const getTasksForDate = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return tasks.filter(task => task.dueDate === dateStr);
  };

  const hasTasksOnDate = (date: Date) => {
    return getTasksForDate(date).length > 0;
  };

  const hasCompletedTasksOnDate = (date: Date) => {
    const dateTasks = getTasksForDate(date);
    return dateTasks.some(task => task.completed);
  };

  const hasHighPriorityTasksOnDate = (date: Date) => {
    const dateTasks = getTasksForDate(date);
    return dateTasks.some(task => task.priority === 'high' && !task.completed);
  };

  const modifiers = {
    hasTasks: (date: Date) => hasTasksOnDate(date),
    hasCompleted: (date: Date) => hasCompletedTasksOnDate(date),
    hasHighPriority: (date: Date) => hasHighPriorityTasksOnDate(date),
  };

  const modifiersStyles = {
    hasTasks: {
      background: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
      color: '#1d4ed8',
      fontWeight: '600',
      borderRadius: '8px',
      border: '2px solid #93c5fd',
    },
    hasCompleted: {
      background: 'linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%)',
      color: '#166534',
      fontWeight: '600',
      borderRadius: '8px',
      border: '2px solid #86efac',
    },
    hasHighPriority: {
      background: 'linear-gradient(135deg, #fef2f2 0%, #fecaca 100%)',
      color: '#dc2626',
      fontWeight: '700',
      borderRadius: '8px',
      border: '2px solid #fca5a5',
    },
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 h-full">
      {/* Calendar - Takes up more space */}
      <Card className="lg:col-span-3 h-full overflow-hidden">
        <CardHeader className="bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 text-white">
          <CardTitle className="text-xl font-bold">Task Calendar</CardTitle>
        </CardHeader>
        <CardContent className="p-6 h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
          <div className="h-full flex flex-col">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              modifiers={modifiers}
              modifiersStyles={modifiersStyles}
              className="rounded-xl border-3 border-gradient-to-r from-blue-200 to-purple-200 p-6 flex-1 w-full bg-white/80 backdrop-blur-sm shadow-xl"
              classNames={{
                months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0 w-full",
                month: "space-y-4 w-full",
                caption: "flex justify-center pt-3 relative items-center text-xl font-bold",
                caption_label: "text-xl font-bold bg-gradient-to-r from-blue-700 to-purple-700 bg-clip-text text-transparent",
                nav: "space-x-2 flex items-center",
                nav_button: "h-10 w-10 bg-gradient-to-r from-blue-100 to-purple-100 hover:from-blue-200 hover:to-purple-200 text-blue-700 rounded-xl transition-all duration-200 shadow-md",
                table: "w-full border-collapse space-y-3",
                head_row: "flex w-full mb-2",
                head_cell: "text-gray-700 rounded-lg w-full font-bold text-base py-3 text-center bg-gradient-to-r from-gray-100 to-slate-100",
                row: "flex w-full mt-3",
                cell: "h-16 w-full text-center text-base p-2 relative hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 rounded-xl transition-all duration-300",
                day: "h-14 w-full p-2 font-semibold hover:bg-gradient-to-r hover:from-blue-100 hover:to-purple-100 hover:text-blue-800 rounded-xl transition-all duration-300 text-base shadow-sm",
                day_selected: "bg-gradient-to-br from-blue-500 via-purple-500 to-indigo-600 text-white hover:from-blue-600 hover:via-purple-600 hover:to-indigo-700 font-bold shadow-xl border-2 border-white",
                day_today: "bg-gradient-to-br from-emerald-400 via-teal-400 to-cyan-500 text-white font-bold shadow-lg border-2 border-emerald-300",
                day_outside: "text-gray-400 opacity-50",
                day_disabled: "text-gray-300 opacity-30",
              }}
            />
            
            {/* Legend */}
            <div className="mt-6 bg-gradient-to-br from-white via-blue-50 to-purple-50 p-6 rounded-xl shadow-lg border border-blue-200">
              <h4 className="font-bold text-gray-800 mb-4 text-lg bg-gradient-to-r from-blue-700 to-purple-700 bg-clip-text text-transparent">
                Calendar Legend
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg border-2 border-blue-300 shadow-md flex-shrink-0"></div>
                  <span className="text-gray-700 font-medium">Has tasks</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-lg border-2 border-emerald-300 shadow-md flex-shrink-0"></div>
                  <span className="text-gray-700 font-medium">Completed tasks</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-red-400 to-red-600 rounded-lg border-2 border-red-300 shadow-md flex-shrink-0"></div>
                  <span className="text-gray-700 font-medium">High priority</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-cyan-400 to-emerald-500 rounded-lg border-2 border-cyan-300 shadow-md flex-shrink-0"></div>
                  <span className="text-gray-700 font-medium">Today</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tasks for Selected Date */}
      <Card className="lg:col-span-2 h-full overflow-hidden">
        <CardHeader className="bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-700 text-white">
          <CardTitle className="flex items-center justify-between text-lg font-bold">
            <span className="bg-white/20 px-3 py-1 rounded-lg backdrop-blur-sm">
              {selectedDate ? format(selectedDate, 'MMM dd, yyyy') : 'Select a date'}
            </span>
            {selectedDate && (
              <Button
                onClick={() => setShowAddForm(true)}
                size="sm"
                className="bg-white/20 hover:bg-white/30 text-white border-2 border-white/30 rounded-lg backdrop-blur-sm transition-all duration-200"
              >
                <Plus className="h-4 w-4" />
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4 h-full overflow-y-auto bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
          {/* Add Task Form */}
          {showAddForm && (
            <div className="border-2 border-dashed border-emerald-300 rounded-xl p-5 space-y-4 bg-gradient-to-br from-emerald-50 to-teal-50 shadow-lg">
              <div>
                <Label htmlFor="task-title" className="text-emerald-800 font-semibold text-sm">Task Title</Label>
                <Input
                  id="task-title"
                  value={newTask.title}
                  onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                  placeholder="Enter task title..."
                  className="border-2 border-emerald-200 focus:border-emerald-400 bg-white/80 rounded-lg"
                />
              </div>
              <div>
                <Label htmlFor="task-description" className="text-emerald-800 font-semibold text-sm">Description</Label>
                <Textarea
                  id="task-description"
                  value={newTask.description}
                  onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                  placeholder="Enter task description..."
                  rows={2}
                  className="border-2 border-emerald-200 focus:border-emerald-400 bg-white/80 rounded-lg"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="task-priority" className="text-emerald-800 font-semibold text-sm">Priority</Label>
                  <select
                    id="task-priority"
                    value={newTask.priority}
                    onChange={(e) => setNewTask({...newTask, priority: e.target.value as any})}
                    className="w-full px-3 py-2 border-2 border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white/80"
                  >
                    <option value="high">🔴 High</option>
                    <option value="medium">🟡 Medium</option>
                    <option value="low">🟢 Low</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="task-time" className="text-emerald-800 font-semibold text-sm">Time</Label>
                  <Input
                    id="task-time"
                    type="time"
                    value={newTask.time}
                    onChange={(e) => setNewTask({...newTask, time: e.target.value})}
                    className="border-2 border-emerald-200 focus:border-emerald-400 bg-white/80 rounded-lg"
                  />
                </div>
              </div>
              <div className="flex space-x-3">
                <Button onClick={addTaskToDate} size="sm" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 shadow-lg">
                  <Save className="h-3 w-3 mr-1" />
                  Save
                </Button>
                <Button
                  onClick={() => setShowAddForm(false)}
                  variant="outline"
                  size="sm"
                  className="border-2 border-gray-300 hover:bg-gradient-to-r hover:from-gray-50 hover:to-slate-50"
                >
                  <X className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Tasks List */}
          {tasksForSelectedDate.length === 0 ? (
            <div className="text-center py-12 text-gray-500 bg-gradient-to-br from-white to-gray-50 rounded-xl border-2 border-dashed border-gray-300 shadow-lg">
              <div className="text-6xl mb-4">📅</div>
              <p className="text-lg font-medium">{selectedDate ? 'No tasks for this date' : 'Select a date to view tasks'}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {tasksForSelectedDate.map((task) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  onToggle={handleToggleTask}
                  onDelete={onDeleteTask}
                  onUpdate={onUpdateTask}
                  isEditing={editingTask === task.id}
                  onEdit={setEditingTask}
                  getPriorityColor={getPriorityColor}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onUpdate: (id: string, updates: Partial<Task>) => void;
  isEditing: boolean;
  onEdit: (id: string | null) => void;
  getPriorityColor: (priority: string) => string;
}

const TaskItem = ({ task, onToggle, onDelete, onUpdate, isEditing, onEdit, getPriorityColor }: TaskItemProps) => {
  const [editTitle, setEditTitle] = useState(task.title);
  const [editDescription, setEditDescription] = useState(task.description);
  const [editTime, setEditTime] = useState(task.time || "");

  const handleSave = () => {
    onUpdate(task.id, { 
      title: editTitle, 
      description: editDescription,
      time: editTime 
    });
  };

  return (
    <div className={`border-2 rounded-xl p-3 transition-all duration-200 shadow-sm ${
      task.completed 
        ? 'opacity-75 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200' 
        : 'bg-white hover:shadow-md border-gray-200 hover:border-blue-300'
    }`}>
      <div className="flex items-start space-x-3">
        <button
          onClick={() => onToggle(task.id)}
          className={`mt-1 w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all duration-200 ${
            task.completed
              ? 'bg-gradient-to-r from-green-500 to-emerald-500 border-green-500 text-white shadow-lg'
              : 'border-gray-300 hover:border-green-500 hover:bg-green-50'
          }`}
        >
          {task.completed && <Check className="h-4 w-4" />}
        </button>

        <div className="flex-1 min-w-0">
          {isEditing ? (
            <div className="space-y-2">
              <Input
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="text-sm border-blue-200 focus:border-blue-400"
              />
              <Textarea
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                className="text-sm border-blue-200 focus:border-blue-400"
                rows={2}
              />
              <Input
                type="time"
                value={editTime}
                onChange={(e) => setEditTime(e.target.value)}
                className="text-sm border-blue-200 focus:border-blue-400"
              />
              <div className="flex space-x-2">
                <Button onClick={handleSave} size="sm" variant="outline" className="bg-green-50 border-green-300 text-green-700 hover:bg-green-100">
                  <Save className="h-3 w-3" />
                </Button>
                <Button onClick={() => onEdit(null)} size="sm" variant="outline" className="bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100">
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ) : (
            <>
              <h4 className={`font-semibold text-sm ${task.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                {task.title}
              </h4>
              {task.description && (
                <p className={`text-xs mt-1 ${task.completed ? 'line-through text-gray-400' : 'text-gray-600'}`}>
                  {task.description}
                </p>
              )}
              <div className="flex items-center space-x-2 mt-2">
                <span className={`text-xs px-3 py-1 rounded-full border-2 font-medium ${getPriorityColor(task.priority)}`}>
                  {task.priority === 'high' ? '🔴' : task.priority === 'medium' ? '🟡' : '🟢'} {task.priority}
                </span>
                {task.time && (
                  <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full font-medium">
                    🕐 {task.time}
                  </span>
                )}
              </div>
            </>
          )}
        </div>

        {!isEditing && (
          <div className="flex space-x-1">
            <button
              onClick={() => onEdit(task.id)}
              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200"
            >
              <Edit3 className="h-4 w-4" />
            </button>
            <button
              onClick={() => onDelete(task.id)}
              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all duration-200"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskCalendar;
