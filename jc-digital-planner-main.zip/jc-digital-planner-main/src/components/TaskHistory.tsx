
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar, Search, Filter, Check, Clock } from "lucide-react";
import { format, parseISO } from "date-fns";

interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  priority: "high" | "medium" | "low";
  dueDate: string;
  time?: string;
  completedAt?: string;
}

interface TaskHistoryProps {
  tasks: Task[];
  onClose: () => void;
}

const TaskHistory = ({ tasks, onClose }: TaskHistoryProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterPriority, setFilterPriority] = useState("all");

  const completedTasks = tasks.filter(task => task.completed);

  const filteredTasks = completedTasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPriority = filterPriority === "all" || task.priority === filterPriority;
    return matchesSearch && matchesPriority;
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-600 bg-red-50 border-red-200";
      case "medium": return "text-yellow-600 bg-yellow-50 border-yellow-200";
      case "low": return "text-green-600 bg-green-50 border-green-200";
      default: return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const groupTasksByDate = (tasks: Task[]) => {
    const grouped: { [key: string]: Task[] } = {};
    tasks.forEach(task => {
      const completedDate = task.completedAt ? format(parseISO(task.completedAt), 'yyyy-MM-dd') : 'Unknown';
      if (!grouped[completedDate]) {
        grouped[completedDate] = [];
      }
      grouped[completedDate].push(task);
    });
    return grouped;
  };

  const groupedTasks = groupTasksByDate(filteredTasks);
  const sortedDates = Object.keys(groupedTasks).sort().reverse();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-6 w-6" />
              <span>Complete Task History</span>
            </CardTitle>
            <Button onClick={onClose} variant="ghost" className="text-white hover:bg-white/20">
              ✕
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6 overflow-y-auto max-h-[75vh]">
          {/* Search and Filter */}
          <div className="mb-6 space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search tasks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <select
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Priorities</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              Total completed tasks: {completedTasks.length}
            </div>
          </div>

          {/* Tasks grouped by completion date */}
          {sortedDates.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium">No completed tasks found</p>
              <p>Complete some tasks to see your history here!</p>
            </div>
          ) : (
            <div className="space-y-6">
              {sortedDates.map(date => (
                <div key={date} className="space-y-3">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2 border-b border-gray-200 pb-2">
                    <Calendar className="h-5 w-5 text-blue-600" />
                    <span>{date === 'Unknown' ? 'Unknown Date' : format(parseISO(date), 'EEEE, MMMM dd, yyyy')}</span>
                    <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                      {groupedTasks[date].length} tasks
                    </span>
                  </h3>
                  <div className="grid gap-3">
                    {groupedTasks[date].map(task => (
                      <div key={task.id} className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                        <div className="flex items-start space-x-3">
                          <div className="w-5 h-5 rounded border-2 bg-green-500 border-green-500 text-white flex items-center justify-center mt-1">
                            <Check className="h-3 w-3" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-gray-900 line-through">{task.title}</h4>
                            {task.description && (
                              <p className="text-sm text-gray-600 line-through mt-1">{task.description}</p>
                            )}
                            <div className="flex items-center space-x-3 mt-2">
                              <span className={`text-xs px-2 py-1 rounded-full border ${getPriorityColor(task.priority)}`}>
                                {task.priority}
                              </span>
                              <span className="text-xs text-gray-500">
                                Due: {format(parseISO(task.dueDate), 'MMM dd, yyyy')}
                              </span>
                              {task.time && (
                                <span className="text-xs text-gray-500">
                                  Time: {task.time}
                                </span>
                              )}
                              {task.completedAt && (
                                <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                                  Completed: {format(parseISO(task.completedAt), 'MMM dd, h:mm a')}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TaskHistory;
