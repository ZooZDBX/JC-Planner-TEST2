import { useState } from "react";
import { Table, TableBody } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import TimetableHeader from "./timetable/TimetableHeader";
import TimetableTableHeader from "./timetable/TimetableTableHeader";
import TimetableRowComponent from "./timetable/TimetableRow";

interface TimetableEntry {
  time: string;
  monday: { subject: string; classroom: string; teacher: string };
  tuesday: { subject: string; classroom: string; teacher: string };
  wednesday: { subject: string; classroom: string; teacher: string };
  thursday: { subject: string; classroom: string; teacher: string };
  friday: { subject: string; classroom: string; teacher: string };
}

interface TimetableStructure {
  weekdays: TimetableEntry[];
  friday: TimetableEntry[];
}

interface FormattedTimetableProps {
  timetableData: TimetableEntry[] | TimetableStructure;
  onUpdate: (data: TimetableEntry[] | TimetableStructure) => void;
}

const FormattedTimetable = ({ timetableData, onUpdate }: FormattedTimetableProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<TimetableEntry[] | TimetableStructure>(timetableData);

  const fridayTimes = [
    '07:45 - 07:50',
    '07:50 - 08:35',
    '08:35 - 09:20',
    '10:30 - 11:15',
    '11:15 - 12:00'
  ];

  // Check if data is the new structure or legacy format
  const isStructuredData = (data: any): data is TimetableStructure => {
    return data && typeof data === 'object' && 'weekdays' in data && 'friday' in data;
  };

  const handleEdit = () => {
    if (isStructuredData(timetableData)) {
      setEditData({ 
        weekdays: [...timetableData.weekdays], 
        friday: [...timetableData.friday] 
      });
    } else {
      setEditData([...timetableData]);
    }
    setIsEditing(true);
  };

  const handleSave = () => {
    onUpdate(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    if (isStructuredData(timetableData)) {
      setEditData({ 
        weekdays: [...timetableData.weekdays], 
        friday: [...timetableData.friday] 
      });
    } else {
      setEditData([...timetableData]);
    }
    setIsEditing(false);
  };

  const updateCell = (
    section: 'weekdays' | 'friday' | 'main', 
    rowIndex: number, 
    day: keyof Omit<TimetableEntry, 'time'>, 
    field: 'subject' | 'classroom' | 'teacher', 
    value: string
  ) => {
    if (isStructuredData(editData)) {
      const newData = { ...editData };
      if (section === 'weekdays') {
        newData.weekdays[rowIndex] = { 
          ...newData.weekdays[rowIndex], 
          [day]: { 
            ...newData.weekdays[rowIndex][day], 
            [field]: value 
          } 
        };
      } else if (section === 'friday') {
        newData.friday[rowIndex] = { 
          ...newData.friday[rowIndex], 
          [day]: { 
            ...newData.friday[rowIndex][day], 
            [field]: value 
          } 
        };
      }
      setEditData(newData);
    } else {
      const newData = [...editData as TimetableEntry[]];
      newData[rowIndex] = { 
        ...newData[rowIndex], 
        [day]: { 
          ...newData[rowIndex][day], 
          [field]: value 
        } 
      };
      setEditData(newData);
    }
  };

  const updateTime = (section: 'weekdays' | 'friday' | 'main', rowIndex: number, value: string) => {
    if (isStructuredData(editData)) {
      const newData = { ...editData };
      if (section === 'weekdays') {
        newData.weekdays[rowIndex] = { ...newData.weekdays[rowIndex], time: value };
      } else if (section === 'friday') {
        newData.friday[rowIndex] = { ...newData.friday[rowIndex], time: value };
      }
      setEditData(newData);
    } else {
      const newData = [...editData as TimetableEntry[]];
      newData[rowIndex] = { ...newData[rowIndex], time: value };
      setEditData(newData);
    }
  };

  if (isStructuredData(timetableData)) {
    const currentData = isStructuredData(editData) ? editData : { weekdays: [], friday: [] };
    
    return (
      <div>
        <TimetableHeader
          isEditing={isEditing}
          onEdit={handleEdit}
          onSave={handleSave}
          onCancel={handleCancel}
        />
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Monday - Thursday (with Friday Times)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TimetableTableHeader />
                <TableBody>
                  {currentData.weekdays.map((entry, index) => (
                    <TimetableRowComponent
                      key={index}
                      entry={entry}
                      index={index}
                      isEditing={isEditing}
                      fridayTimes={fridayTimes}
                      onTimeUpdate={(idx, value) => updateTime('weekdays', idx, value)}
                      onCellUpdate={(idx, day, field, value) => updateCell('weekdays', idx, day, field, value)}
                      section="weekdays"
                      fridayEntry={currentData.friday[index]}
                    />
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Legacy format support
  const currentData = Array.isArray(editData) ? editData : [];

  return (
    <Card>
      <CardHeader>
        <TimetableHeader
          isEditing={isEditing}
          onEdit={handleEdit}
          onSave={handleSave}
          onCancel={handleCancel}
        />
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TimetableTableHeader isLegacyFormat />
            <TableBody>
              {currentData.map((entry, index) => (
                <TimetableRowComponent
                  key={index}
                  entry={entry}
                  index={index}
                  isEditing={isEditing}
                  fridayTimes={fridayTimes}
                  onTimeUpdate={(idx, value) => updateTime('main', idx, value)}
                  onCellUpdate={(idx, day, field, value) => updateCell('main', idx, day, field, value)}
                  section="main"
                />
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default FormattedTimetable;
