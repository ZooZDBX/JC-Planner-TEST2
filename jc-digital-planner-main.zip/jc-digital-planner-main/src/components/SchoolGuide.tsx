import { useState } from "react";
import { Search, Phone, Users, Mail } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const guideData = [
  {
    id: "rules-1",
    section: "rules",
    title: "General Conduct",
    content:
      "All students are expected to conduct themselves in a respectful and responsible manner both on and off school premises. This includes treating teachers, staff, and fellow students with courtesy and respect. Students should follow instructions promptly and participate positively in all school activities. Inappropriate behavior such as bullying, harassment, or disruption of classes will not be tolerated. Students must maintain a positive attitude and contribute to a safe and supportive learning environment for everyone.",
  },
  {
    id: "rules-2",
    section: "rules",
    title: "Dress Code and Uniform Policy",
    content:
      "Students must adhere strictly to the school's dress code policy, which promotes modesty, neatness, safety, and equality among all students. All clothing should be appropriate for an educational environment and free from distracting elements. Items explicitly not permitted include: revealing or inappropriate clothing, clothing with offensive graphics or text, gang-related symbols or colors, clothing that poses safety hazards in laboratories or workshops, and accessories that could be used as weapons. Where school uniforms are required, they must be worn according to the specific guidelines provided at the beginning of each academic year. Students who violate the dress code will be required to change into appropriate attire or contact parents for suitable clothing.",
  },
  {
    id: "rules-3",
    section: "rules",
    title: "Academic Integrity and Honesty",
    content:
      "Academic honesty and integrity are fundamental principles that underpin the entire educational process at our institution. All students are expected to demonstrate honesty in their academic work and maintain the highest standards of scholarly conduct. Cheating in any form, including but not limited to copying from other students, using unauthorized materials during examinations, or submitting work that is not entirely your own, is strictly prohibited. Plagiarism, which includes using someone else's ideas, words, or work without proper citation and acknowledgment, will result in serious disciplinary action. Unauthorized collaboration on assignments designated as individual work is also considered a violation. All work submitted must be original and represent the student's own efforts unless specifically permitted otherwise. Students found violating academic integrity policies will face disciplinary action that may include failure of the assignment, failure of the course, suspension, or other appropriate consequences as determined by the administration.",
  },
  {
    id: "rules-4",
    section: "rules",
    title: "Technology and Device Usage",
    content:
      "Personal electronic devices, including smartphones, tablets, and laptops, may be used during designated times and in approved locations only, as specified by school policy and individual teacher guidelines. During instructional time, all personal devices must be silenced and stored in designated areas unless specifically permitted by the teacher for educational purposes related to the lesson. Students are responsible for the security of their personal devices and the school accepts no liability for loss, theft, or damage. Misuse of technology, including but not limited to cyberbullying, accessing inappropriate content, violating network security, sharing passwords, or using devices to cheat, will result in immediate disciplinary action. The school reserves the right to monitor network usage and may confiscate devices when policy violations occur. Students must also comply with the school's Acceptable Use Policy for internet and network resources.",
  },
  {
    id: "safety-1",
    section: "safety",
    title: "Emergency Procedures and Protocols",
    content:
      "In the event of any emergency situation, students must immediately follow the clear instructions provided by teachers, staff members, and emergency personnel without question or delay. All students are required to familiarize themselves with the emergency evacuation routes posted in every classroom and common area. During fire drills, which are conducted monthly to ensure preparedness, students must evacuate quickly and quietly to the designated assembly points in an orderly fashion. During lockdown procedures, students must remain completely silent, follow teacher instructions precisely, and stay in secure locations until the all-clear signal is given by authorized personnel. It is essential that emergency contact information for parents and guardians be kept current with the school office at all times. Students should never use emergency exits during non-emergency situations, and any tampering with emergency equipment will result in serious disciplinary consequences.",
  },
  {
    id: "safety-2",
    section: "safety",
    title: "Anti-Bullying Policy and Prevention",
    content:
      "Our school maintains a comprehensive zero-tolerance policy for bullying in any form, recognizing that bullying creates an unsafe learning environment and can have lasting negative effects on victims. This policy covers all forms of bullying including physical aggression, verbal harassment, social exclusion, cyberbullying through digital platforms, and any other behavior intended to intimidate, harm, or humiliate another person. Students who experience bullying, witness bullying incidents, or have knowledge of bullying behavior are strongly encouraged and expected to report it immediately to a teacher, counselor, administrator, or through our anonymous reporting system. All reports will be investigated promptly, thoroughly, and with complete confidentiality to protect all parties involved. The school provides comprehensive support services for both victims and perpetrators of bullying, including counseling, mediation, and educational programs designed to prevent future incidents and promote positive relationships among students.",
  },
  {
    id: "safety-3",
    section: "safety",
    title: "Digital Citizenship and Cyber Safety",
    content:
      "In our increasingly connected digital world, students must understand and practice responsible digital citizenship both at school and at home. Students should exercise extreme caution when using the internet and social media platforms, being particularly careful never to share personal information such as home addresses, phone numbers, or financial information with strangers online. Never arrange to meet online contacts in person without proper parental supervision and approval. Students must immediately report any inappropriate online behavior, cyberbullying, or concerning content to a trusted adult, whether it occurs during school hours or personal time. It is crucial to use strong, unique passwords for all accounts and to understand that digital footprints are permanent and can significantly impact future educational and career opportunities. Students should always think carefully before posting or sharing any content online, considering how it might reflect on themselves and their school community.",
  },
  {
    id: "leadership-1",
    section: "leadership",
    title: "Student Government and Council Participation",
    content:
      "The Student Council serves as the official representative body that advocates for student interests, voices student concerns to the administration, and organizes meaningful school-wide events and initiatives. Annual elections are held each fall for key positions including president, vice president, secretary, treasurer, and class representatives, providing students with valuable experience in democratic processes and civic engagement. Student Council members meet weekly during designated times to discuss important student concerns, plan upcoming events, review school policies, and develop proposals for school improvement initiatives. All students are strongly encouraged to participate actively in the democratic process by voting in elections, attending candidate forums, and considering running for office themselves. The Student Council also collaborates closely with school administration and faculty to ensure that student voices are heard in important decisions affecting school life and policies.",
  },
  {
    id: "leadership-2",
    section: "leadership",
    title: "Club and Organization Leadership Opportunities",
    content:
      "Students can develop and demonstrate essential leadership skills by taking active roles in the numerous clubs and organizations available throughout our school community. Club officers, including presidents, vice presidents, secretaries, and treasurers, are responsible for planning and organizing regular meetings, coordinating special events and activities, managing club resources and budgets, and serving as liaisons between their organizations and the school administration. Students interested in starting a new club or organization must secure faculty sponsorship, submit a detailed proposal to the administration for approval, and demonstrate sufficient student interest and commitment. Our school regularly offers comprehensive leadership development workshops and training sessions designed to help students develop crucial skills such as public speaking, event planning, team building, conflict resolution, and effective communication that will serve them well throughout their academic and professional careers.",
  },
];

const SchoolGuide = () => {
  const [searchTerm, setSearchTerm] = useState("");

  // Helper function to highlight search terms in text
  const highlightText = (text: string, searchTerm: string) => {
    if (!searchTerm) return text;
    
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    const parts = text.split(regex);
    
    return parts.map((part, index) => 
      regex.test(part) ? (
        <span key={index} className="bg-yellow-200 font-semibold">
          {part}
        </span>
      ) : part
    );
  };

  // Filter sections based on search term
  const getFilteredSections = () => {
    if (!searchTerm) {
      return {
        showCollegeInfo: true,
        showSchedule: true,
        showAttendance: true,
        showUniform: true,
        showTechnology: true,
        showEmergency: true,
        showTips: true,
        showStaff: true,
        showLeadership: true,
        filteredGuideData: guideData
      };
    }

    const searchTermLower = searchTerm.toLowerCase();
    
    // Check which sections contain the search term
    const showCollegeInfo = 
      "college information contact details postal address physical address".includes(searchTermLower) ||
      "jumeirah college po box dubai uae street al safa".includes(searchTermLower) ||
      "tel fax phone email".includes(searchTermLower);
      
    const showSchedule = 
      "schedule timetable period registration break study time friday monday tuesday wednesday thursday ramadan".includes(searchTermLower) ||
      "07:45 08:45 09:40 10:00 10:55 11:50 12:30 13:10 14:05 15:00".includes(searchTermLower);
      
    const showAttendance = 
      "attendance punctuality absent absence late tardy khda 98%".includes(searchTermLower) ||
      "7:42 detention pastoral reception safeguarding".includes(searchTermLower);
      
    const showUniform = 
      "uniform dress code presentation appearance".includes(searchTermLower) ||
      "shirt blouse trousers skirt sweater tie belt shoes socks".includes(searchTermLower) ||
      "green black white burgundy maroon piping sixth form".includes(searchTermLower) ||
      "hair makeup nail polish piercing tattoo".includes(searchTermLower) ||
      "key stage threads threadsme.com".includes(searchTermLower);
      
    const showTechnology = 
      "technology device phone smartphone tablet laptop".includes(searchTermLower) ||
      "cyberbullying network security password acceptable use".includes(searchTermLower);
      
    const showEmergency = 
      "emergency contact office guidance counselor nurse security".includes(searchTermLower);
      
    const showTips = 
      "tips success bookmarked reference teacher policy".includes(searchTermLower);
      
    const showStaff = 
      "staff directory principal vice assistant head year pastoral counselor".includes(searchTermLower) ||
      "brain pedder kesterton ring ryan cahalane ford kinsey tank".includes(searchTermLower) ||
      "woolcock burrows deans walsh radcliffe scott connall brady balfe sam".includes(searchTermLower);

    const showLeadership = 
      "leadership support counsellors medical team student executive".includes(searchTermLower) ||
      "brain pedder kesterton conmara sam doctor benish nurse baretto laude".includes(searchTermLower) ||
      "clara glenwright skye beattie lucian sanay ramchandani bruno".includes(searchTermLower);

    const filteredGuideData = guideData.filter((item) => {
      return (
        item.title.toLowerCase().includes(searchTermLower) ||
        item.content.toLowerCase().includes(searchTermLower)
      );
    });

    return {
      showCollegeInfo,
      showSchedule,
      showAttendance,
      showUniform,
      showTechnology,
      showEmergency,
      showTips,
      showStaff,
      showLeadership,
      filteredGuideData
    };
  };

  const {
    showCollegeInfo,
    showSchedule,
    showAttendance,
    showUniform,
    showTechnology,
    showEmergency,
    showTips,
    showStaff,
    showLeadership,
    filteredGuideData
  } = getFilteredSections();

  const groupedData = filteredGuideData.reduce((acc, item) => {
    if (!acc[item.section]) {
      acc[item.section] = [];
    }
    acc[item.section].push(item);
    return acc;
  }, {} as Record<string, typeof filteredGuideData>);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900">School Guide</h2>
        <p className="text-gray-600">
          Your go-to resource for school rules, safety guidelines, and student
          leadership opportunities.
        </p>
      </div>

      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <Input
          type="search"
          placeholder="Search for topics..."
          className="pl-10"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Accordion type="multiple" className="space-y-4">
        {/* College Information */}
        {showCollegeInfo && (
          <AccordionItem value="college-info" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Phone className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("College Information", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-4">
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">Contact Details</h4>
                  <div className="space-y-1 text-gray-600">
                    <p>Tel: 04 395 5524</p>
                    <p>Fax: 04 395 4586</p>
                    <p>www.gemsjc.com</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">Postal Address</h4>
                  <div className="text-gray-600">
                    <p>Jumeirah College PO Box 74856</p>
                    <p>Dubai, UAE</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">Physical Address</h4>
                  <div className="text-gray-600">
                    <p>Street 19</p>
                    <p>Al Safa 1 Dubai, UAE</p>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        {/* College Schedule */}
        {showSchedule && (
          <AccordionItem value="college-schedule" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-purple-100 p-2 rounded-lg">
                  <Phone className="h-5 w-5 text-purple-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("College Schedule", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-6">
                {/* Regular Schedule */}
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-4">Monday to Thursday</h4>
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>07:45-07:50</span>
                      <span>Registration</span>
                    </div>
                    <div className="flex justify-between">
                      <span>07:50-08:45</span>
                      <span>Period 1</span>
                    </div>
                    <div className="flex justify-between">
                      <span>08:45-09:40</span>
                      <span>Period 2</span>
                    </div>
                    <div className="flex justify-between">
                      <span>09:40-10:00</span>
                      <span>Break</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10:00-10:55</span>
                      <span>Period 3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10:55-11:50</span>
                      <span>Period 4</span>
                    </div>
                    <div className="flex justify-between">
                      <span>11:50-12:30</span>
                      <span>Break 2</span>
                    </div>
                    <div className="flex justify-between">
                      <span>12:30-13:10</span>
                      <span>Study Period</span>
                    </div>
                    <div className="flex justify-between">
                      <span>13:10-14:05</span>
                      <span>Period 5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>14:05-15:00</span>
                      <span>Period 6</span>
                    </div>
                  </div>

                  <h4 className="text-lg font-medium text-gray-900 mb-4 mt-6">Friday</h4>
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2 text-sm max-w-md">
                    <div className="flex justify-between">
                      <span>07:45-07:50</span>
                      <span>Registration</span>
                    </div>
                    <div className="flex justify-between">
                      <span>07:50-08:35</span>
                      <span>Period 1</span>
                    </div>
                    <div className="flex justify-between">
                      <span>08:35-09:20</span>
                      <span>Period 2</span>
                    </div>
                    <div className="flex justify-between">
                      <span>09:20-10:05</span>
                      <span>Period 3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10:05-10:30</span>
                      <span>Break</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10:30-11:15</span>
                      <span>Period 4</span>
                    </div>
                    <div className="flex justify-between">
                      <span>11:15-12:00</span>
                      <span>Period 5</span>
                    </div>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mt-4">
                    <p className="text-sm text-yellow-800">
                      <strong>Please note:</strong> All students should be inside the College gates by no later than 7.42am. 
                      This is to enable all students to reach their form room before 7.45am.
                    </p>
                  </div>
                </div>

                {/* Ramadan Schedule */}
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-4">DURING RAMADAN</h4>
                  
                  <h5 className="text-md font-medium text-gray-800 mb-3">Monday to Thursday</h5>
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2 text-sm mb-4">
                    <div className="flex justify-between">
                      <span>08.30 - 08.35</span>
                      <span>Morning Registration</span>
                    </div>
                    <div className="flex justify-between">
                      <span>08.35 - 09.15</span>
                      <span>Period 1</span>
                    </div>
                    <div className="flex justify-between">
                      <span>09.15 - 09.55</span>
                      <span>Period 2</span>
                    </div>
                    <div className="flex justify-between">
                      <span>09.55 - 10.10</span>
                      <span>Break</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10.10 - 10.50</span>
                      <span>Period 3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10.50 - 11.30</span>
                      <span>Period 4</span>
                    </div>
                    <div className="flex justify-between">
                      <span>11.30 - 11.55</span>
                      <span>Lunch</span>
                    </div>
                    <div className="flex justify-between">
                      <span>11.55 - 12.10</span>
                      <span>Study Time</span>
                    </div>
                    <div className="flex justify-between">
                      <span>12.10 - 12.50</span>
                      <span>Period 5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>12.50 - 13.30</span>
                      <span>Period 6</span>
                    </div>
                  </div>

                  <h5 className="text-md font-medium text-gray-800 mb-3">Friday</h5>
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2 text-sm mb-4 max-w-md">
                    <div className="flex justify-between">
                      <span>08.30 - 09.10</span>
                      <span>Period 1</span>
                    </div>
                    <div className="flex justify-between">
                      <span>09.10 - 09:50</span>
                      <span>Period 2</span>
                    </div>
                    <div className="flex justify-between">
                      <span>09:50 - 10.30</span>
                      <span>Period 3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10.30 - 10.50</span>
                      <span>Break</span>
                    </div>
                    <div className="flex justify-between">
                      <span>10:50 - 11:25</span>
                      <span>Period 4</span>
                    </div>
                    <div className="flex justify-between">
                      <span>11:25 - 12:00</span>
                      <span>Period 5</span>
                    </div>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                    <p className="text-sm text-yellow-800">
                      <strong>Please note:</strong> All students should be inside the College gates by no later than 8.27am. 
                      This is to enable all students to reach their form room before 8.30am.
                    </p>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        {/* Attendance & Punctuality */}
        {showAttendance && (
          <AccordionItem value="attendance" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Phone className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("Attendance & Punctuality", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-3">Attendance & Absences</h4>
                  <p className="text-gray-600 mb-4">
                    Research shows that attendance and punctuality are the single most important factors in school success. 
                    Absence will impact upon a student's ability to maximise their potential. Occasionally there may be times 
                    when absence is unavoidable, and on these occasions, it will be the student's responsibility to catch up 
                    on all work missed. KHDA expectations include an attendance rate of over 98%.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">KHDA expectations include an attendance rate of over 98%</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        Occasionally there may be times when absence is unavoidable - it will be the student's responsibility 
                        to catch up on all work missed
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        No student may leave the College premises without parental permission until the end of the College 
                        day for safeguarding purposes
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        If there is a need to collect your child during the day, you will need to collect them in person from Reception
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">Notify the office if you'll be absent due to illness</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-3">Punctuality</h4>
                  <p className="text-gray-600 mb-4">
                    As a College we believe that punctuality displays a person's respect for people and time. Being punctual 
                    is an indication that you are a reliable person and respectful of others. It is important to set positive 
                    patterns for the future and the development of such habits develop at a young age.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">All students should have passed through the entrance gates at the latest by 7:42am</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        The back gate will also close at 7:42am and students who arrive after this time will be recorded as late
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                    <h5 className="font-medium text-gray-900 mb-2">Sanctions for late arrival:</h5>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• 2 x lates in one week - Tuesday after school pastoral detention</li>
                      <li>• 4 x lates in one month - Tuesday after school pastoral detention</li>
                    </ul>
                    <p className="text-sm text-gray-600 mt-2">
                      Pastoral detentions take place on Tuesday afternoons from 3pm-4pm and students should bring homework or a reading book. 
                      Students will not be allowed on their devices during this time. Detentions are supervised by Heads of Year.
                    </p>
                    <p className="text-sm text-gray-600 mt-2">
                      A persistent pattern of lateness could result in a short-term exclusion from the College or eventual 
                      non-enrolment for the following academic year.
                    </p>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        {/* Personal Presentation and Uniform */}
        {showUniform && (
          <AccordionItem value="uniform" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-indigo-100 p-2 rounded-lg">
                  <Users className="h-5 w-5 text-indigo-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("Personal Presentation and Uniform", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-6">
                {/* General Guidelines */}
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-3">General Guidelines</h4>
                  <p className="text-gray-600 mb-4">
                    Personal presentation is very important. The aim of our uniform is for students to present a neat, 
                    business-like appearance at all times and to demonstrate pride in being members of Jumeirah College. 
                    A high standard of personal appearance is expected of all students at all times, both inside the 
                    College campus and outside in the community.
                  </p>
                  <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mb-4">
                    <p className="text-sm text-yellow-800">
                      <strong>Important:</strong> Full and correct uniform must be worn in, and whilst travelling to and from, 
                      College. This also applies after school and travelling home after activities and on all school trips 
                      unless otherwise informed by the trip leader.
                    </p>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        Shirts/blouses should be of an appropriate size (not overly large/short) and trousers should not be short/ankle length
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">Shoes should be leather and polished regularly</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        When sweaters are not being worn they should be stored in the student's locker
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        Students wear full uniform to all Parent Teacher Consultations and any after school formal events
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        No visible body modifications e.g. tattoos or piercings (Girls: other than one in each lobe) are allowed, including plastic studs
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">
                        Students' hair must be of a natural colour (black, blonde, brown, red natural tones)
                      </p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600">All students are permitted to wear a watch</p>
                    </div>
                  </div>
                </div>

                {/* Key Stage 3 and 4 */}
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-4">Key Stage 3 and Key Stage 4</h4>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Girls */}
                    <div className="bg-pink-50 p-4 rounded-lg border border-pink-200">
                      <h5 className="text-md font-semibold text-pink-800 mb-3">Girls</h5>
                      <div className="space-y-3 text-sm">
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Uniform and Appearance:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Short-sleeved white blouse with Jumeirah College logo</li>
                            <li>• Dark green mid-calf or ankle length skirt or dark green regulation trousers to foot/shoe level</li>
                            <li>• Dark green sweater with Jumeirah College logo</li>
                            <li>• Black leather, covered toe, flat low-heeled sensible shoes</li>
                            <li>• Black or white plain socks</li>
                            <li>• Head scarves should be black, white, green or burgundy</li>
                            <li>• Girls are permitted to wear one stud in each earlobe</li>
                            <li>• Students are not permitted to wear nail varnish/false nails or make up</li>
                            <li>• No rings, bracelets or necklaces should be worn</li>
                            <li>• PE Kit is only permitted on days when students have PE on their timetable</li>
                          </ul>
                        </div>
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Hair:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Girls' hair should be tied back fully</li>
                            <li>• Long hair (collar length or longer) must be tied back</li>
                            <li>• May style hair in plaits, ponytail or bunches as long as hair is tidy and fully back</li>
                            <li>• No shaved or dramatically short sections</li>
                            <li>• Hair accessories should be plain and of matching College colours (white, dark green, burgundy or black)</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Boys */}
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h5 className="text-md font-semibold text-blue-800 mb-3">Boys</h5>
                      <div className="space-y-3 text-sm">
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Uniform and Appearance:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Short-sleeved white shirt with Jumeirah College logo</li>
                            <li>• Dark green regulation trousers to foot/shoe level</li>
                            <li>• Dark green sweater with Jumeirah College logo</li>
                            <li>• College tie - should be tied in a neat knot that covers the fastened top button</li>
                            <li>• Plain black leather belt (large logos on the fastening are not allowed)</li>
                            <li>• Black leather traditional, logo free shoes</li>
                            <li>• Plain black socks only</li>
                            <li>• Boys' shirts should be properly tucked in at the waist at all times</li>
                            <li>• PE Kit is only permitted on days when students have PE on their timetable</li>
                          </ul>
                        </div>
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Hair:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Boys' hair must be well above the collar at the back, above the ears and off the face</li>
                            <li>• Short hair (no shorter than a No 3 barber cut) is acceptable</li>
                            <li>• Boys' hairstyles should be neat, without any hair accessories</li>
                            <li>• Should not be elaborate or exaggerated in style, no undercut, no shaved in designs</li>
                            <li>• In KS3 & 4 boys are expected to be clean shaven every day</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Key Stage 5 */}
                <div>
                  <h4 className="text-lg font-medium text-gray-900 mb-4">Key Stage 5 (Sixth Form)</h4>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Girls */}
                    <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                      <h5 className="text-md font-semibold text-purple-800 mb-3">Girls</h5>
                      <div className="space-y-3 text-sm">
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Uniform and Appearance:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Short-sleeved white blouse with Jumeirah College logo and maroon piping (Sixth Form blouse)</li>
                            <li>• Long black skirt or black regulation trousers, with no back pockets, foot/shoe level</li>
                            <li>• Black leather, covered toe, flat low-heeled sensible school shoes (below 5 cm at the back)</li>
                            <li>• Black plain over-the-ankle socks</li>
                            <li>• Black V-neck sweater, with Jumeirah College logo</li>
                            <li>• Head scarves should be black, white, green or burgundy</li>
                            <li>• Girls are permitted one stud in each earlobe, one bracelet, one necklace and one ring (discrete)</li>
                            <li>• Discrete makeup may be worn if appropriate for a business environment</li>
                            <li>• Nail varnish may be worn as long as it is clear or French manicure. Nail extensions are not permitted</li>
                          </ul>
                        </div>
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Hair:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Girls' hair should be clipped back fully off the face at all times</li>
                            <li>• There should not be any shaved or dramatically short bits</li>
                            <li>• Hair accessories should be plain and of matching College colours</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Boys */}
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <h5 className="text-md font-semibold text-green-800 mb-3">Boys</h5>
                      <div className="space-y-3 text-sm">
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Uniform and Appearance:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Short-sleeved white shirt with Jumeirah College logo and maroon piping (Sixth Form shirt)</li>
                            <li>• Black regulation trousers, with no back pockets, to foot/shoe level</li>
                            <li>• Plain black leather belt (large logos on the fastening are not allowed)</li>
                            <li>• Black V-neck sweater with Jumeirah College logo</li>
                            <li>• Black leather traditional, logo free shoe</li>
                            <li>• Plain black socks</li>
                            <li>• Boys' shirts should be properly tucked in at the waist at all times</li>
                          </ul>
                        </div>
                        <div>
                          <h6 className="font-medium text-gray-900 mb-2">Hair:</h6>
                          <ul className="space-y-1 text-gray-600">
                            <li>• Boys' hair must be well above the collar at the back and off the ears and face</li>
                            <li>• Short hair (no shorter than a No 3 barber cut) is acceptable</li>
                            <li>• Boys' hairstyles should be neat, without any hair accessories</li>
                            <li>• Should not be elaborate or exaggerated in style</li>
                            <li>• Boys are expected to be neatly shaven every day</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Uniform Purchase Information */}
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <h4 className="text-lg font-medium text-gray-900 mb-3">Uniform Purchase Information</h4>
                  <p className="text-gray-600 mb-3">
                    The uniform is compulsory throughout the College and should be purchased online through Threads at{" "}
                    <span className="font-medium">www.threadsme.com</span>. An order form can be faxed to{" "}
                    <span className="font-medium">04 340 9638</span> or uniform can be bought directly from the Threads store 
                    on the ground floor (G09) of the Times Square Centre, off Sheikh Zayed Road.
                  </p>
                  <p className="text-gray-600 mb-3">
                    We advise that you plan this well in advance, as the company's stock can very quickly be depleted.
                  </p>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4" />
                      <span>800 847 3237</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>support@threadsme.com</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> Heads of Year reserve the right to determine whether a hairstyle is 
                    acceptable/unacceptable, in line with the above-mentioned criteria.
                  </p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        {/* Technology Policy */}
        {showTechnology && (
          <AccordionItem value="technology" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Phone className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("Technology Policy", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-4">
                {groupedData.rules?.map((item) => (
                  item.title === "Technology and Device Usage" && (
                    <div key={item.id}>
                      <p className="text-gray-600">
                        {highlightText(item.content, searchTerm)}
                      </p>
                    </div>
                  )
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        {/* Staff Directory */}
        {showStaff && (
          <AccordionItem value="staff-directory" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-gray-100 p-2 rounded-lg">
                  <Users className="h-5 w-5 text-gray-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("Staff Directory", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-8">
                {/* Principal & Senior Leadership Team */}
                <div>
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <h4 className="text-lg font-medium text-gray-900">Principal & Senior Leadership Team</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr N Brain</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>Principal_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Vice-Principal & Safeguard Lead</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr S Pedder</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>s.pedder_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Vice-Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr R Kesterton</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>r.kesterton_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Vice-Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms F Ring</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>f.ring_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Assistant Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms M Ryan</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>m.ryan1_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Assistant Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr M Cahalane</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>m.cahalane_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Assistant Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms N Ford</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>n.hinken_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Assistant Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr A Kinsey</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>a.kinsey_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow opacity-60">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Assistant Principal</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">TBC</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>TBC</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Senior Teacher</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr P Tank</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>p.tank_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow opacity-60">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-blue-600">Senior Teacher</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">TBC</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>TBC</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Pastoral Staff */}
                <div>
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <h4 className="text-lg font-medium text-gray-900">Pastoral Staff</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 7</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr J Woolcock</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>j.woolcock_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 8</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms S Burrows</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>s.burrows_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 9</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms N Deans</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>n.deans_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Deputy Head of Y7-Y9</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms K Walsh</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>c.walsh_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 10</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mrs L Radcliffe</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>l.radcliffe_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 11</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms M Scott</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>m.scott_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Deputy Head of Y10-Y11</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Mr T Connall</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>t.connall_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow opacity-60">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 12</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">TBC</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>TBC</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Year 13</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms M Brady</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>m.brady_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Deputy Head of Y12-Y13</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms A Balfe</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>a.balfe_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Head of Sixth Form</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms M Ryan</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>m.ryan1_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Student Counsellor</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms K Sam</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>k.sam_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base text-green-600">Student Counsellor</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="font-medium text-gray-900 mb-1">Ms N Kesterton</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Mail className="h-3 w-3" />
                          <span>n.kesterton_jcd@gemsedu.com</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        {/* School Leadership */}
        {showLeadership && (
          <AccordionItem value="school-leadership" className="bg-white rounded-xl shadow-sm border border-gray-200">
            <AccordionTrigger className="px-6 py-4 hover:no-underline">
              <div className="flex items-center space-x-3">
                <div className="bg-purple-100 p-2 rounded-lg">
                  <Users className="h-5 w-5 text-purple-600" />
                </div>
                <span className="text-lg font-semibold">
                  {highlightText("School Leadership", searchTerm)}
                </span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-6 pb-6">
              <div className="space-y-6">
                <div className="text-center">
                  <img 
                    src="/lovable-uploads/c47f7250-8188-4b14-a7f4-c402ff76cde1.png" 
                    alt="School Leadership and Support Staff" 
                    className="w-full max-w-4xl mx-auto rounded-lg shadow-md"
                  />
                </div>
                <div className="text-center">
                  <p className="text-gray-600">
                    Our dedicated leadership team and support staff are here to help you succeed. 
                    If you require support or are feeling unhappy, these are the key people you can speak to.
                  </p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        )}
      </Accordion>

      {/* Emergency Contacts */}
      {showEmergency && (
        <div className="bg-gradient-to-r from-red-400 to-orange-400 rounded-xl p-6 text-white">
          <div className="flex items-center space-x-3 mb-6">
            <Phone className="h-6 w-6" />
            <h3 className="text-xl font-semibold">
              {highlightText("Emergency Contacts", searchTerm)}
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-semibold mb-2">Main Office</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>04 395 5524</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>✉</span>
                  <span>office@gemsjc.com</span>
                </div>
              </div>
            </div>

            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-semibold mb-2">Guidance Counselor</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>(555) 123-4568</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>✉</span>
                  <span>counseling@gemsjc.com</span>
                </div>
              </div>
            </div>

            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-semibold mb-2">Nurse's Office</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>(555) 123-4569</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>✉</span>
                  <span>health@gemsjc.com</span>
                </div>
              </div>
            </div>

            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-semibold mb-2">Security</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>(555) 123-4570</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>✉</span>
                  <span>security@gemsjc.com</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quick Tips for Success */}
      {showTips && (
        <div className="bg-green-50 rounded-xl p-6 border border-green-200">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white text-sm">💡</span>
            </div>
            <h3 className="text-xl font-semibold text-green-800">
              {highlightText("Quick Tips for Success", searchTerm)}
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-green-700">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>Keep this guide bookmarked for quick reference</span>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>Ask teachers if you're unsure about any policy</span>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>Report any concerns to trusted staff members</span>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>Stay updated with any policy changes announced</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SchoolGuide;
