
import { useState } from 'react';
import Tesseract from 'tesseract.js';

interface TimetableEntry {
  time: string;
  monday: { subject: string; classroom: string; teacher: string };
  tuesday: { subject: string; classroom: string; teacher: string };
  wednesday: { subject: string; classroom: string; teacher: string };
  thursday: { subject: string; classroom: string; teacher: string };
  friday: { subject: string; classroom: string; teacher: string };
}

interface TimetableStructure {
  weekdays: TimetableEntry[];
  friday: TimetableEntry[];
}

export const useTimetableProcessor = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const extractTextFromImage = async (imageUrl: string): Promise<string> => {
    try {
      const { data: { text } } = await Tesseract.recognize(imageUrl, 'eng', {
        logger: m => console.log(m)
      });
      return text;
    } catch (err) {
      throw new Error('Failed to extract text from image');
    }
  };

  const parseTimeSlot = (timeStr: string): string => {
    // Clean and format time strings
    const cleaned = timeStr.trim().replace(/[^\d:]/g, '');
    if (cleaned.includes(':')) {
      return cleaned;
    }
    return timeStr.trim();
  };

  const parseSubject = (subjectStr: string): string => {
    // Clean up subject names
    return subjectStr.trim().replace(/\s+/g, ' ');
  };

  const processTimetableText = (text: string): TimetableEntry[] => {
    const lines = text.split('\n').filter(line => line.trim());
    const timetableData: TimetableEntry[] = [];
    
    // Updated time slots based on the new timings provided
    const commonTimeSlots = [
      '07:45 - 07:50',
      '08:45 - 09:40',
      '10:00 - 10:55',
      '10:55 - 11:50',
      '12:30 - 13:10',
      '13:10 - 14:05',
      '14:05 - 15:00'
    ];

    // Try to identify day headers
    const dayPattern = /(monday|tuesday|wednesday|thursday|friday)/i;
    const timePattern = /\d{1,2}:\d{2}/;

    // If we can't parse the structure well, create a template
    if (timetableData.length === 0) {
      commonTimeSlots.forEach(timeSlot => {
        timetableData.push({
          time: timeSlot,
          monday: { subject: '', classroom: '', teacher: '' },
          tuesday: { subject: '', classroom: '', teacher: '' },
          wednesday: { subject: '', classroom: '', teacher: '' },
          thursday: { subject: '', classroom: '', teacher: '' },
          friday: { subject: '', classroom: '', teacher: '' }
        });
      });
    }

    return timetableData;
  };

  const processImage = async (imageUrl: string): Promise<TimetableEntry[]> => {
    setIsProcessing(true);
    setError(null);

    try {
      const extractedText = await extractTextFromImage(imageUrl);
      console.log('Extracted text:', extractedText);
      
      const processedData = processTimetableText(extractedText);
      return processedData;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to process timetable';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const createEmptyTimetable = (): TimetableStructure => {
    // Monday-Thursday time slots - updated to new timings
    const weekdayTimeSlots = [
      '07:45 - 07:50',
      '08:45 - 09:40',
      '10:00 - 10:55',
      '10:55 - 11:50',
      '12:30 - 13:10',
      '13:10 - 14:05',
      '14:05 - 15:00'
    ];

    // Friday specific time slots
    const fridayTimeSlots = [
      '07:45 - 07:50',
      '07:50 - 08:35',
      '08:35 - 09:20',
      '10:30 - 11:15',
      '11:15 - 12:00'
    ];

    const weekdays = weekdayTimeSlots.map(time => ({
      time,
      monday: { subject: '', classroom: '', teacher: '' },
      tuesday: { subject: '', classroom: '', teacher: '' },
      wednesday: { subject: '', classroom: '', teacher: '' },
      thursday: { subject: '', classroom: '', teacher: '' },
      friday: { subject: '-', classroom: '', teacher: '' } // Not used for weekdays section
    }));

    const friday = fridayTimeSlots.map(time => ({
      time,
      monday: { subject: '-', classroom: '', teacher: '' }, // Not used for Friday section
      tuesday: { subject: '-', classroom: '', teacher: '' }, // Not used for Friday section
      wednesday: { subject: '-', classroom: '', teacher: '' }, // Not used for Friday section
      thursday: { subject: '-', classroom: '', teacher: '' }, // Not used for Friday section
      friday: { subject: '', classroom: '', teacher: '' }
    }));

    return { weekdays, friday };
  };

  return {
    processImage,
    createEmptyTimetable,
    isProcessing,
    error
  };
};

export type { TimetableStructure };
